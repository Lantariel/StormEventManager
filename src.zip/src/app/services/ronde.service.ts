import {Injectable} from '@angular/core';
import {Ronde} from '../models/ronde.model';
import {Subject} from 'rxjs';
import {firebase} from '@firebase/app';
import {Match} from '../models/match.model';
import {Joueur} from '../models/joueur.model';

@Injectable({
  providedIn: 'root'
})

export class RondeService {

}
