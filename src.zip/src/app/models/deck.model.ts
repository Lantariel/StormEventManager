export class Deck {

  deckname: string ;
  deckformat: string ;

  tournamentHistory: string[] ;
  registeredPilots: string[] ;


  constructor() {  }
}
