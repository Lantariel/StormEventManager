import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-des-joueurs',
  templateUrl: './liste-des-joueurs.component.html',
  styleUrls: ['./liste-des-joueurs.component.scss']
})
export class ListeDesJoueursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
